foo = 'ns2_folder!'
