
class Bar:
    def bar(self):
        pass
